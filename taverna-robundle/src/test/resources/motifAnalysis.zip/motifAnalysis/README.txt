This analysis work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 2.0 Generic License (http://creativecommons.org/licenses/by-nc-sa/2.0/). 
Some workflows may have more restrictive licenses, so if you wish to use them please refer to the different workflow execution platforms for more information.

The workflows have been exported from:
myExperiment: http://myexperiment.org/
WINGS: http://www.wings-workflows.org/
VISTRAILS + Crowdlabs: http://www.vistrails.org/index.php/Main_Page, http://www.crowdlabs.org/
Galaxy: https://main.g2.bx.psu.edu/workflow