ID: 	1057
TITLE: 	Load PDF from directory
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1057/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1057/download/_untitled__603421.t2flow
