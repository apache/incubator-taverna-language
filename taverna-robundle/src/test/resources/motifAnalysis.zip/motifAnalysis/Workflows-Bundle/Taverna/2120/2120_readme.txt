ID: 	2120
TITLE: 	Generate Atom Signatures of molecules given SDF as input
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2120/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2120/download/generate_atom_signatures_of_molecules_given_sdf_as_input_542065.t2flow
