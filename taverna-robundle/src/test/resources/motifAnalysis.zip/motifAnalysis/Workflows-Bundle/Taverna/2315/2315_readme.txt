ID: 	2315
TITLE: 	Convert GML to SVG
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2315/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2315/download/convert_gml_to_svg_479271.t2flow
