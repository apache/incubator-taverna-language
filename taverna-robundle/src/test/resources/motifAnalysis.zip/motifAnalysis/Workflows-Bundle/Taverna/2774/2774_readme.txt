ID: 	2774
TITLE: 	Darwin Core 2 CSV Shim Service with parameter
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2774/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2774/download/darwin_core_2_csv_shim_service_with_parameter_687995.t2flow
