ID: 	2455
TITLE: 	Comparing Quantities using HyperLEDA
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2455/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2455/download/comparing_quantities_using_hyperleda_870342.t2flow
