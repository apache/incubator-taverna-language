ID: 	2917
TITLE: 	Sesame service to get the RA and DEC of a list of objects
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2917/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2917/download/sesame_service_to_get_the_ra_and_dec_of_a_list_of_objects_148172.t2flow
