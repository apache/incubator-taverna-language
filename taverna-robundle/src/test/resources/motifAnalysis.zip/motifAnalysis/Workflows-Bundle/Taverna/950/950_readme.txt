ID: 	950
TITLE: 	workflow1
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/950/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/950/download/workflow1_352574.t2flow
