ID: 	2920
TITLE: 	Calculating the internal extinction with data from leda
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2920/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2920/download/_untitled__772953.t2flow
