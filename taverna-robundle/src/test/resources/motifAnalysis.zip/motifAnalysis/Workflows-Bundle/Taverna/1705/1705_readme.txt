ID: 	1705
TITLE: 	EMBL-EBI ClustalW2 (SOAP)
LICENSE TYPE: 	Apache
SVG PATH: 	http://www.myexperiment.org/workflows/1705/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1705/download/478548_78.t2flow
