ID: 	2826
TITLE: 	Taverna interaction service with BioSTIF using occurrence Data
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2826/versions/5/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2826/download/taverna_interaction_service_with_biostif_using_occurrence_data_66123.t2flow
