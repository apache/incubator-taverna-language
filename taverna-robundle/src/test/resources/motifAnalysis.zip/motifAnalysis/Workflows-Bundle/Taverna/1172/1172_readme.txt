ID: 	1172
TITLE: 	Compare genome, extract proteins which are drug targets, apply to KEGG pathway
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1172/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1172/download/retrieve_genome_seqn_using_gi_ids_899654.t2flow
