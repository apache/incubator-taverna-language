ID: 	2478
TITLE: 	ALA show species
LICENSE TYPE: 	by
SVG PATH: 	http://www.myexperiment.org/workflows/2478/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2478/download/_untitled__981450.t2flow
