ID: 	1183
TITLE: 	blastp of target vs source database
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1183/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1183/download/blastp_of_target_vs_source_database_182346.t2flow
