ID: 	2477
TITLE: 	ALA full search
LICENSE TYPE: 	by
SVG PATH: 	http://www.myexperiment.org/workflows/2477/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2477/download/_untitled__727467.t2flow
