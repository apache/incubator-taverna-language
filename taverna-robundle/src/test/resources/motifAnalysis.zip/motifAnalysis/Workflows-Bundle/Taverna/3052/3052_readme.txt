ID: 	3052
TITLE: 	Adjusting galaxy parameters using galfit
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3052/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3052/download/adjusting_galaxy_parameters_using_galfit_725015.t2flow
