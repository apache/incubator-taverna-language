ID: 	2921
TITLE: 	Example of jdbc
LICENSE TYPE: 	GPL
SVG PATH: 	http://www.myexperiment.org/workflows/2921/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2921/download/example_of_jdbc_214852.t2flow
