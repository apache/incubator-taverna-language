ID: 	3204
TITLE: 	Searching for near galaxies in NED service
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3204/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3204/download/searching_near_galaxies_in_ned_444404.t2flow
