ID: 	1384
TITLE: 	EBI_InterProScan for Taverna 2
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1384/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1384/download/ebi_interproscan_for_taverna_2_293715.t2flow
