ID: 	2613
TITLE: 	Propagation of physical quantities in the calculation of luminosities of galaxies
LICENSE TYPE: 	by-nc-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2613/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2613/download/propagation_of_physical_quantities_in_the_calculation_of_luminosities_of_galaxies_329415.t2flow
