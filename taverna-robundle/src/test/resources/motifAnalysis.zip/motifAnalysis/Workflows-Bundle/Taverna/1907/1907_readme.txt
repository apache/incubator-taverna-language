ID: 	1907
TITLE: 	Associate goes X ray  flares with active regions
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1907/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1907/download/associate_hessi_flares_with_active_regions_800457.t2flow
