ID: 	2980
TITLE: 	VOTables from NED Web Services
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2980/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2980/download/_untitled__413716.t2flow
