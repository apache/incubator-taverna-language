ID: 	2925
TITLE: 	Convert table to CDS format
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2925/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2925/download/_untitled__461970.t2flow
