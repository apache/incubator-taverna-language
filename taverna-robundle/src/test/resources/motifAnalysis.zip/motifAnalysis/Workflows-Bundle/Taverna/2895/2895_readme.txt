ID: 	2895
TITLE: 	Raster SHIM service
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2895/versions/6/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2895/download/raster_shim_service_340329.t2flow
