ID: 	1188
TITLE: 	Retrieve Genome Seqn using gi nos
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1188/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1188/download/retrieve_genome_seqn_using_gi_nos_72628.t2flow
