ID: 	1694
TITLE: 	Phylogenetic Tree
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1694/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1694/download/_untitled__611342.t2flow
