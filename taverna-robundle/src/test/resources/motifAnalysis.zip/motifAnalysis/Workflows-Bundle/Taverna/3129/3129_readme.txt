ID: 	3129
TITLE: 	Build plots from galfit and ellipse results 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3129/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3129/download/build_plots_from_galfit_and_ellipse_results__147914.t2flow
