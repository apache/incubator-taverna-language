ID: 	1065
TITLE: 	Terms from collection of text files
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1065/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1065/download/terms_from_collection_of_text_files_853894.t2flow
