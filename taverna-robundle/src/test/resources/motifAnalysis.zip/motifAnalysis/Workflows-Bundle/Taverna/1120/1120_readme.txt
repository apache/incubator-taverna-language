ID: 	1120
TITLE: 	Kegg pathway diagrams
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1120/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1120/download/kegg_pathway_diagrams_93816.t2flow
