ID: 	833
TITLE: 	getGoTermsFromUniprotId
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/833/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/833/download/getgotermsfromuniprotid_420087.t2flow
