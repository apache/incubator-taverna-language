ID: 	1264
TITLE: 	EntrezGeneId_to_GOFunction
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1264/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1264/download/entrezgeneid_to_gofunction_600621.t2flow
