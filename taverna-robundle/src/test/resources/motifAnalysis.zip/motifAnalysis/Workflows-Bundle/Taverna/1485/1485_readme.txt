ID: 	1485
TITLE: 	BLAST against the GPCRDB
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1485/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1485/download/blast_against_the_gpcrdb_292350.t2flow
