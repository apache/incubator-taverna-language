ID: 	1012
TITLE: 	Get TP53 Mutation Function Entries  And TP53 Cell Line Entries By MutAa And Codon Number
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1012/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1012/download/get_tp53_mutation_function_entries__and_tp53_cell_line_entries_by_mutaa_and_codon_number_148040.xml
