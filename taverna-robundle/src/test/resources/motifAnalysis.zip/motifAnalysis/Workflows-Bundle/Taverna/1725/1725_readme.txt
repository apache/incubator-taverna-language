ID: 	1725
TITLE: 	ART-2a Classification Considering Different Origins Result As PDF
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1725/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1725/download/art-2a_classification_considering_different_origins_result_as_pdf_968892.t2flow
