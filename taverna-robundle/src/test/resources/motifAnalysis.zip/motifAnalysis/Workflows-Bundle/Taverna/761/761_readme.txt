ID: 	761
TITLE: 	DataBiNS with Kegg ID
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/761/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/761/download/databins_with_kegg_id_1197.t2flow
