ID: 	3046
TITLE: 	Run sextractor using a votable
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3046/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3046/download/run_sextractor_using_a_votable_869069.t2flow
