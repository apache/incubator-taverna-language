ID: 	941
TITLE: 	getTimololFromMassBank
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/941/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/941/download/_untitled__610491.t2flow
