ID: 	1652
TITLE: 	BiomartAndEMBOSSAnalysis
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1652/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1652/download/biomartandembossanalysis_262461.t2flow
