ID: 	1060
TITLE: 	Termine with c-value threshold
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/1060/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1060/download/_untitled__962176.t2flow
