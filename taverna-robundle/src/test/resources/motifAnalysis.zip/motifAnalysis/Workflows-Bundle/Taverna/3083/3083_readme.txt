ID: 	3083
TITLE: 	Convert a list into a VO Column
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3083/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3083/download/convert_a_list_into_a_vo_column_722658.t2flow
