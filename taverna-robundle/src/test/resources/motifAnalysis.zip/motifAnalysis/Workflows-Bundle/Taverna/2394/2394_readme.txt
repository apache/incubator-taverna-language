ID: 	2394
TITLE: 	Name resolver of galaxies parsing the output using a python tool
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2394/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2394/download/name_resolver_of_galaxies_parsing_the_output_using_a_python_tool_371098.t2flow
