ID: 	3167
TITLE: 	Detect ellipse failures and get votable without ellipse failures
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3167/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3167/download/detect_ellipse_failures_and_get_votable_without_ellipse_failures_686692.t2flow
