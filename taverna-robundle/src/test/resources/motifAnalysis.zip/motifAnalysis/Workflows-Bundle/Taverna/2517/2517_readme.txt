ID: 	2517
TITLE: 	Ice Class Map pixel analysis (NERSC)
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2517/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2517/download/_untitled__194053.t2flow
