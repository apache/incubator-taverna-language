ID: 	3044
TITLE: 	Create configuration files from a template and a votable 
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3044/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3044/download/_untitled__440275.t2flow
