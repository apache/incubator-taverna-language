ID: 	2560
TITLE: 	Calculation of distances, magnitutes and luminosities using HyperLEDA
LICENSE TYPE: 	by-nc-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2560/versions/4/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2560/download/calculation_of_distances__magnitutes_and_luminosities_using_hyperleda_220027.t2flow
