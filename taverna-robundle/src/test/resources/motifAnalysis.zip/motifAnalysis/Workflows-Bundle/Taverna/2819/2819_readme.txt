ID: 	2819
TITLE: 	Split VOTable into its values
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2819/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2819/download/split_votable_into_its_values_340951.t2flow
