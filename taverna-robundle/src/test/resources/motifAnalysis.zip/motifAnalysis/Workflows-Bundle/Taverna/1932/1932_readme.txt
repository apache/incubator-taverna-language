ID: 	1932
TITLE: 	DevinTheDevil
LICENSE TYPE: 	by-nd
SVG PATH: 	http://www.myexperiment.org/workflows/1932/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/1932/download/devinthedevil_510396.t2flow
