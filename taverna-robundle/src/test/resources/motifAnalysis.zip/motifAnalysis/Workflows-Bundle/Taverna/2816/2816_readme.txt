ID: 	2816
TITLE: 	Propagation of the Solar Energetic Particles to the Sun
LICENSE TYPE: 	BSD
SVG PATH: 	http://www.myexperiment.org/workflows/2816/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2816/download/propagation_of_the_solar_energetic_particles_to_the_sun_941235.t2flow
