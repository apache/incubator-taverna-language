ID: 	3048
TITLE: 	Ajusting galaxy paramenters using sextractor
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/3048/versions/5/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/3048/download/ajusting_galaxy_paramenters_using_sextractor_690193.t2flow
