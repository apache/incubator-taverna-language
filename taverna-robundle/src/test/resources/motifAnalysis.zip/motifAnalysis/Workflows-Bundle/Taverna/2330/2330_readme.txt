ID: 	2330
TITLE: 	GT: Database - Master SNP Call Table
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2330/versions/1/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2330/download/gt__database_-_master_snp_call_table_579664.t2flow
