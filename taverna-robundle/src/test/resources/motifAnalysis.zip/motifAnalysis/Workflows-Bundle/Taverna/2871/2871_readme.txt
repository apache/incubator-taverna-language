ID: 	2871
TITLE: 	2 BioSTIF interactions called consecutivelly with csv data
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2871/versions/3/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2871/download/2_biostif_interactions_called_consecutivelly_with_csv_data_957893.t2flow
