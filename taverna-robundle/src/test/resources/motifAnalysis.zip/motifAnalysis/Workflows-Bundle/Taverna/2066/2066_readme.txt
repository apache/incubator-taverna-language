ID: 	2066
TITLE: 	GRASS-GIS orchestration using pyWPS
LICENSE TYPE: 	by-sa
SVG PATH: 	http://www.myexperiment.org/workflows/2066/versions/2/previews/svg
WF CONTENTPATH: 	http://www.myexperiment.org/workflows/2066/download/grass-gis_orchestration_using_pywps_733725.t2flow
