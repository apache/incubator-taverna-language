README
For reasons beyond our control, some galaxy workflow specifications and diagrams couldn't be downloaded. We provide however the link where they can be viewed online.

Bristol workflow to get sorted unique proper pair mapped reads. URL: https://main.g2.bx.psu.edu/u/davidmatthews/w/workflow-to-get-sorted-unique-proper-pair-mapped-reads

metagenomic analysis. URL: https://main.g2.bx.psu.edu/u/ballen/w/imported-metagenomic-analysis

Grace's Workflow for LV samples (single-end, fastq, b37) URL: https://main.g2.bx.psu.edu/u/muehlsch/w/graces-workflow-for-lv-samples-single-end-fastq-b37

Prep pgSnp file to run SIFT URL: https://main.g2.bx.psu.edu/u/Belinda/w/prep-pgsnp-file-to-run-sift

Basic RNA-Seq Analysis - Differential Expression (Functional Genomics Workshop 2012) URL: https://main.g2.bx.psu.edu/u/mejia-guerra/w/basic-rna-seq-analysis---differential-expression-functional-genomics-workshop-2012

RTTS Mapper URL: https://main.g2.bx.psu.edu/u/lukaszkielpinski/w/rtts-mapper

Transform 'Stitch Gene blocks' FASTA blocks to standardized FASTA file URL: https://main.g2.bx.psu.edu/u/galaxyproject/w/transform-stitch-gene-blocks-fasta-blocks-to-standardized-fasta-file

Clone of 'Index Separation-FASTQ-Tophat' shared by 'ajtong@ucla.edu' URL: https://main.g2.bx.psu.edu/u/asahakyan/w/clone-of-index-separation-fastq-tophat-shared-by-ajtonguclaedu

Basic Text Manipulation II (Functional Genomics Workshop 2012) URL: https://main.g2.bx.psu.edu/u/mejia-guerra/w/basic-text-manipulation-ii-functional-genomics-workshop-2012

Basic Text Manipulation (Functional Genomics Workshop 2012) URL: https://main.g2.bx.psu.edu/u/mejia-guerra/w/basic-text-manipulation-functional-genomics-workshop-2012